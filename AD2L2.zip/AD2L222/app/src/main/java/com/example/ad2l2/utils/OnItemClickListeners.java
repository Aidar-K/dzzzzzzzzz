package com.example.ad2l2.utils;

public interface OnItemClickListeners {
    void onClick(int position);
    void longClick(int position);
}
