package com.example.ad2l2.ui;

public class App {
    public static App instane;

}
