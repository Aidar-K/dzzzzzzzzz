package com.example.ad2l2.ui.home;

public interface Listen {
    void setDatForFrom (HomeModel homeModel, int position);
}
