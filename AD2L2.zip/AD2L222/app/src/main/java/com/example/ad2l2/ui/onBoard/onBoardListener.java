package com.example.ad2l2.ui.onBoard;

public interface  onBoardListener {
    void onPageChanged(int position);
}
